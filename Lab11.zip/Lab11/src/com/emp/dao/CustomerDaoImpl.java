package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import com.emp.bin.CustomerBean;
import com.emp.bin.MobileBean;
import com.emp.exception.MobileException;
import com.emp.util.DBConnection;

public class CustomerDaoImpl implements CustomerDao
{
	Scanner sc = new Scanner(System.in);
	public int generateEmployeeId()
	{
		int id=0;
		Connection  con = null;
		String str= "select purchaseid_seq.nextval from dual";
		try 
		{
			con=DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(str);
			rs.next();
			id=rs.getInt(1);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return id;
	}
	
	@Override
	public int addCustomer(CustomerBean bean) throws MobileException
	{
		int id=0;
		Connection con= null;
		//LocalDate date = LocalDate.now();
		LocalDate today = LocalDate.now();
		
		String cmd="insert into purchasedetails1 values(?,?,?,?,?,?)";
		
		try 
		{
			con=DBConnection.getConnection();
			id=generateEmployeeId();
			//Date date1 = date.toDate();
			//Date date1 = Date.from(LocalDate.now());
			//Date date = new Date();
			
			//Date date1 = new Date(10/11/1996);
			System.out.println(id);
			PreparedStatement ps = con.prepareStatement(cmd);
			
			ps.setInt(1,id);
			ps.setString(2,bean.getCname());
			ps.setString(3, bean.getMailid());
			ps.setString(4, bean.getPurchasedate());
			ps.setInt(5, bean.getPhoneno());
			ps.setInt(6, bean.getMobileid());
			
			System.out.println("abc");
			int n=ps.executeUpdate();
			System.out.println(n);
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new MobileException("unable to insert");
		}
		return id;
	}

	@Override
	public int deleteMob(int deleteId) throws MobileException 
	{
		Connection con= null;
		Statement stmt =null;
		
		
		try {
			con=DBConnection.getConnection();
			String cmd="delete from mobiles where mobileid ="+ deleteId;
			 stmt =con.createStatement();
			
			 ResultSet result =stmt.executeQuery(cmd);
		}
		catch (Exception e) 
		{
			throw new MobileException("unable to delete");
		}
		return deleteId;
	}

	@Override
	public List<MobileBean> viewAllMob() throws MobileException
	{
		Connection con= null;
		Statement stmt =null;
		
		List<MobileBean> employeeList = new ArrayList<MobileBean>();
		try {
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			String cmd = "select * from mobiles";
			PreparedStatement ps = null;
			ResultSet resultset = null;

			ps = con.prepareStatement(cmd);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				MobileBean bean1 = new MobileBean();
				bean1.setMobileid(resultset.getInt(1));
				bean1.setName(resultset.getString(2));
				bean1.setPrice(resultset.getInt(3));
				bean1.setQuantity(resultset.getString(4));
				
				employeeList.add(bean1);

			}
		} catch (SQLException e) {
			System.out.println(e);

		}
		return employeeList;

	}

	@Override
	public MobileBean viewMobById(int viewId) throws MobileException
	{
		Connection con= null;
		Statement stmt =null;
		MobileBean bean= new MobileBean();
		
		try {
			con=DBConnection.getConnection();
			String cmd="select mobileid,name,price,quantity from mobiles where mobileid ="+ viewId;
			 stmt =con.createStatement();
			
			 ResultSet result =stmt.executeQuery(cmd);
			 if(result.next())
				{
				 	bean.setMobileid(result.getInt(1));
					bean.setName(result.getString(2));
					bean.setPrice(result.getInt(3));
					bean.setQuantity(result.getString(4));
				}
		}
		catch (Exception e) 
		{
			throw new MobileException("unable to view by id");
		}
		return bean;	
	}

	@Override
	public List<MobileBean> searchByRange(int min, int max)
			throws MobileException 
	{
		Connection con= null;
		Statement stmt =null;
		
		List<MobileBean> employeeList = new ArrayList<MobileBean>();
		try {
			con = DBConnection.getConnection();
			stmt = con.createStatement();
			String cmd = "select * from mobiles where price between "+min+ " and " +max;
			PreparedStatement ps = null;
			ResultSet resultset = null;

			ps = con.prepareStatement(cmd);
			resultset = ps.executeQuery();

			while (resultset.next()) {
				MobileBean bean1 = new MobileBean();
				bean1.setMobileid(resultset.getInt(1));
				bean1.setName(resultset.getString(2));
				bean1.setPrice(resultset.getInt(3));
				bean1.setQuantity(resultset.getString(4));
				
				employeeList.add(bean1);

			}
		} catch (SQLException e) {
			System.out.println(e);

		}
		return employeeList;

	}
}
