package com.emp.service;

import java.util.List;

import com.emp.bin.CustomerBean;
import com.emp.bin.MobileBean;
import com.emp.dao.CustomerDao;
import com.emp.dao.CustomerDaoImpl;
import com.emp.exception.MobileException;

public class CustomerServiceImpl implements CustomerService
{
	private CustomerDao employeedao = new CustomerDaoImpl();

	@Override
	public int addCustomer(CustomerBean bean) throws MobileException 
	{
		int id= employeedao.addCustomer(bean);
		return id;
	}

	@Override
	public int deleteMob(int deleteId) throws MobileException 
	{
		int id = employeedao.deleteMob(deleteId);
		return id;
	}

	@Override
	public List<MobileBean> viewAllMob() throws MobileException 
	{
		CustomerDaoImpl employeeDao = new CustomerDaoImpl();
		List<MobileBean> employeeList = null;

		employeeList = employeeDao.viewAllMob();
		return employeeList;
	}

	@Override
	public  MobileBean viewMobById(int viewId) throws MobileException 
	{
		MobileBean bean = new MobileBean();
		bean = employeedao.viewMobById(viewId);
		return bean;
	}

	@Override
	public List<MobileBean> searchByRange(int min, int max)
			throws MobileException
		{
		CustomerDaoImpl employeeDao = new CustomerDaoImpl();
		List<MobileBean> employeeList = null;

		employeeList = employeeDao.searchByRange(min,max);
		return employeeList;
	}
}
